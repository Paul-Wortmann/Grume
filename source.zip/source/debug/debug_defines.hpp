/**
 * Copyright (C) Paul Wortmann
 * This file is part of "Grume"
 *
 * "Grume" is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 2 only.
 *
 * "Grume" is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with "Grume" If not, see <http://www.gnu.org/licenses/>.
 *
 * @author  Paul Wortmann
 * @email   physhex@gmail.com
 * @website www.physhexgames.com
 * @license GPL V2
 * @date 2011-11-11
 */

#ifndef DEBUG_DEFINES_HPP
#define DEBUG_DEFINES_HPP

#define DEBUG_GL // Enable OpenGL debugging
#define DEBUG_VK // Enable Vulkan debugging
#define DEBUG_LF // Enable Log to file
#define DEBUG_LC // Enable Log to console

#define DEBUG_FILE "debug.log" // Default debug log file name.

#endif //DEBUG_DEFINES_HPP

